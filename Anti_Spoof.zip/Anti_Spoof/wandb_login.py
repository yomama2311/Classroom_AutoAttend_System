import wandb
wandb.login(key="f8b90505309db381cb58d016f8670403992ffad9")