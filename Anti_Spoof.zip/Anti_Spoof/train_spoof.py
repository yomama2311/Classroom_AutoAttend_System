import os
import torch
import wandb
from ultralytics import YOLO

CLASS_NAMES = {0: "fake", 1: "real"}

def train_model():
    print("🔍 CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("🚀 Using GPU:", torch.cuda.get_device_name(0))
        print("💾 Total GPU memory (GB):", round(torch.cuda.get_device_properties(0).total_memory / 1024**3, 2))
    else:
        print("⚠️ Using CPU")

    model = YOLO("yolov8n.pt")

    model.train(
        data="E:/STUDIES/Prj/Anti_Spoof/DATASET/Split_Data/data.yaml",
        epochs=100,
        imgsz=416,
        batch=16,
        patience=10,
        project="Anti_Spoofing_YoLo",
        name="Anti_spoof",
        val=True,
        device=0,
        verbose=True,
        plots=True,
        workers=0,
        close_mosaic=0
    )



def evaluate_model(model_path):
    print("\n🧪 Loading best model for evaluation...")
    model = YOLO(model_path)

    print("🧪 Running model.val()...")
    metrics = model.val()

    # 🧠 Print for local debugging
    print("📊 Returned Metrics:")
    print(f"  box_loss: {metrics.box.loss}")
    print(f"  cls_loss: {metrics.box.cls}")
    print(f"  mAP50: {metrics.box.map50}")
    print(f"  mAP50-95: {metrics.box.map}")

    # ✅ Now log these metrics to Weights & Biases
    wandb.init(project="anti-spoofing-yolo", name="val-logging")
    wandb.log({
        "val/box_loss": metrics.box.loss,
        "val/cls_loss": metrics.box.cls,
        "val/mAP50": metrics.box.map50,
        "val/mAP50-95": metrics.box.map
    })
    wandb.finish()


if __name__ == '__main__':
    train_model()
    evaluate_model("runs/detect/Anti_spoof/weights/best.pt")
