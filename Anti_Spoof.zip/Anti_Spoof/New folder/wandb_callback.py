import wandb

def on_fit_epoch_end(trainer):
    metrics = trainer.metrics
    wandb.log({
        "epoch": trainer.epoch,
        "train/box_loss": metrics.box_loss,
        "train/cls_loss": metrics.cls_loss,
        "train/dfl_loss": metrics.dfl_loss,
        "val/precision": metrics.box.p,
        "val/recall": metrics.box.r,
        "val/mAP50": metrics.box.map50,
        "val/mAP50-95": metrics.box.map,
    })
