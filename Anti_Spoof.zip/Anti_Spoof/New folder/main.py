import wandb
from ultralytics import YOLO

def train_model():
    # Login to W&B
    wandb.login()

    # Init W&B run (optional but useful for naming)
    wandb.init(
        project="anti-spoofing-yolo",
        name="yolov8-anti-spoofing-run",
        config={
            "model": "yolov8n.pt",
            "epochs": 100,
            "imgsz": 416,
            "batch": 16,
            "dataset": "anti-spoof"
        }
    )

    # Load YOLO model
    model = YOLO("yolov8n.pt")

    # Train model — W&B will be auto-logged
    model.train(
        data="E:/STUDIES/Prj/Anti_Spoof/DATASET/Split_Data/data.yaml",
        epochs=100,
        imgsz=416,
        batch=16,
        patience=10,
        project="Anti_Spoofing_YoLo",
        name="Anti_spoof",
        val=True,
        device=0,
        verbose=True,
        plots=True,
        workers=0,
        close_mosaic=0
    )

    # Finish the W&B run (optional but good practice)
    wandb.finish()
